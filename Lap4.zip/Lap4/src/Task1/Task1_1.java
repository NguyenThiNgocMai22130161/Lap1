package Task1;

import java.util.Arrays;

public class Task1_1 {
	// sort by descending order
	public static void selectionSort(int[] array) {
	int n = array.length;
	for (int i = 0; i < n - 1; i++) {
		//Tìm giá trị của phần tử nhỏ nhất trong mảng chưa đc săp xếp
		for (int j = i + 1; j < n; j++) {
			
//		// Hoán đổi phần tử nhỏ nhất với phần tử hiện tại
			if (array[j] > array[i]) {
				int temp = array[j];
				array[j] = array[i];
				array[i] = temp;
			}
		}
			}
	}
	public static void main(String[] args) {
		int[] array = {1,8,0,2,2,0,0,4};
		selectionSort(array);
		
		System.out.println(Arrays.toString(array));
	}
}
