package Task1;

import java.util.Arrays;

public class Task1_3 {
	// sort by descending order
	public static void insertionSort(int[] array) {
	for (int i = 1; i < array.length; i++) {  //phần tử đầu tiên đã đc sắp xếp
		int key = array[i];
		int j = i - 1;
		while (j >= 0 && array[j] < key) {
			array[j + 1] = array[j];
			j--;		
	}
	array[j + 1] = key;
	}
	}
	public static void main(String[] args) {
		int[] array = {4,7,2,5,9,6};
		insertionSort(array);
		
		System.out.println(Arrays.toString(array));
	}
}
