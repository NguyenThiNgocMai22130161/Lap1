package Task2;

import java.util.Arrays;
import java.util.Random;

public class Task2_2 {
	// sort by ascending order
	public static void quickSort (int[] array) {
		quickSort(array, 0, array.length - 1);
	if (array.length <= 1) 
	return ; //ko can sap xep
	}
	private static void quickSort(int[] array, int low, int hight) {
		if (low < hight) {
			// chon truc
			int pivotIndex = getPivot_MedianOfThree(array, low, hight);
			//phan vung mang
			int pivotPosition = partition(array,low,hight,pivotIndex);
			//sap xep mamg con
			quickSort(array, low, pivotPosition - 1);
			quickSort(array, pivotPosition + 1, hight);
		}
	}
	private static int partition(int[] array, int low, int hight, int pivotIndex) {
		int pivotValue = array[pivotIndex];
		swap(array, pivotIndex,hight); // di chuyen den truc cuoi
		
		int i = low ;
		for (int j = low; j < hight; j++) {
			if(array[j] >= pivotValue) { // array[j] < pivotValue => sap xep lon dan
				swap(array , i , j); 
				i++;
			}
		}
		swap (array, i, hight); //di chuyen truc den vi tri cuoi cung
		return i;
	}
	private static void swap(int[] array, int i, int j) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
		
	}
	//select pivot element based on the median of three
	//strategy
	private static int getPivot_MedianOfThree(int[]
	array, int low, int hight) {
	int mid = low +(hight - low) / 2;
	// sắp xếp
	if (array[low] < array[low]) {
		swap (array, low, mid);
	}
	if (array[low] > array[hight]) {
		swap (array, low, hight);
	}
	if (array[mid] < array[hight]) {
		swap (array, mid, hight);
	}
	return mid;
	}
	// select pivot element based on the first element
	//in the array
	private static int getPivot_First(int[] array) {
	return 0;
	}
	// select pivot element based on the last element in
	//the array
	private static int getPivot_Last(int[] array) {
	return array.length - 1;
	}
	// select pivot element based on choosing a randomly
	//element in the array
	private static int getPivot_Random(int[] array) {
	Random ran = new Random();
	return ran.nextInt(array.length);
	}
	public static void main(String[] args) {
		int[] array = {3,5,1,7,9,4};
		quickSort(array);
		System.out.println(Arrays.toString(array));
	}
}
