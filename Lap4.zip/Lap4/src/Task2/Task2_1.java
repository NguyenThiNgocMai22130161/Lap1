package Task2;

import java.util.Arrays;

public class Task2_1 {
	// sort by descending order
	public static void mergeSort(int[] array) {
	if (array.length <= 1) { //Nếu mảng chỉ chứa một phần tử thì tra ve mang
		return ;
	}
	int mid = (array.length/2);
	int[] leftHalf = new int[mid];
	int[] rightHalf = new int[array.length - mid];
	
	//chia mảng thành 2 nửa
	for (int i = 0; i < mid; i++) {
		leftHalf[i] = array[i];
	}
	for (int i = mid; i < array.length; i++) {
		rightHalf[i - mid] = array[i];
	}
	mergeSort(leftHalf);
	mergeSort(rightHalf);
	
	//gộp 2 mảng đã đc xs
	merge(array, leftHalf, rightHalf);
  }

	private static void merge(int[] array, int[] leftHalf, int[] rightHalf) {
		int i = 0; //trái
		int j = 0; //phải
		int k = 0; //mảng ket qua
		
		while( i < leftHalf.length && j < rightHalf.length) {
			if (leftHalf[i] >= rightHalf[j]) {
				array[k] = leftHalf[i];
				i++;
			}else {
			    array[k] = rightHalf[j];
			    j++;
		    }
			k++; //tăng giá trị k lên 1 để chỉ định vị trí tiếp theo trong mảng đã được dịch chuyển
		}
		//kiểm tra xem phần tử nào còn lại trong mảng trái hoặc mảng phải không
		while (i < leftHalf.length) {
			array[k] = leftHalf[i];
			i++;
			k++;
		}
		while (j < rightHalf.length) {
			array[k] = rightHalf[j];
			j++;
			k++;
		}
	}
	public static void main(String[] args) {
		int[] array = {3,8,2,5,1,7,9,6,4};
		mergeSort(array);
		
		System.out.println(Arrays.toString(array));
	}
}
