/**
 * 
 */
/**
 * @author nguye
 *
 */
module Lap7 {
}