package Task1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Clazz {
		private String name;
		private String year;// 2017, 2018, 2019, ...
		private ArrayList<Student> students = new ArrayList<Student>();

		public Clazz(String name, String year) {
			this.name = name;
			this.year = year;
		}
		
		public Clazz() {
			students = new ArrayList<>();
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setYear(String year) {
			this.year = year;
		}

		public void setStudents(ArrayList<Student> students) {
			this.students = students;
		}
		private void addStudent(Student student) {
			students.add(student);
			
		}
		// load all students from filename into the list of students //load all sv từ filename vào ds
        public void loadStudents(String fileName) {
        	try {   // ngoại lệ
        	List<Student> load = StudentUtils.loadStudents(fileName);
			students.addAll(load);
        }catch(IOException e){ //Xử lý ngoại lệ
        	System.out.println(fileName);
        	
        	}
        }
		// sort students according to the given comparator c // sap xep sv
		public void sortStudents(Comparator<Student> c) {
		    students.sort(c);
		}

		// get top n students with highest GPA // lay n sv co tb cao nhat
		public ArrayList<Student> getTopNStudents(int n) {
			 //Sắp xếp danh sách sinh viên theo điểm GPA giảm dần
//			Collections.sort(students, new Comparator<Student>() {
//
//				@Override
//				public int compare(Student o1, Student o2) {
//					// TODO Auto-generated method stub
//					return Double.compare(o2.getGPA(), o1.getGPA());
//				}
//			});
//			// Lấy danh sách n sinh viên đầu tiên
//			ArrayList<Student> top = new ArrayList<Student>();
//			for (int i = 0; i < n && i < students.size(); i++) {
//				top.add(students.get(i));
//			}
//			return top;
//		}
			ArrayList<Student> topStudents = new ArrayList<>(students); // Tạo một bản sao của danh sách sinh viên

		    // Sử dụng Comparator để sắp xếp danh sách sinh viên theo điểm GPA giảm dần
		    topStudents.sort(Comparator.comparingDouble(Student::getGPA).reversed());

		    // Trả về n sinh viên đầu tiên trong danh sách
		    if (topStudents.size() > n) {
		        return new ArrayList<>(topStudents.subList(0, n));
		    } else {
		        return topStudents;
		    }
		}
			


	// remove a student with a given id // xoa sv theo id
		public boolean removeStudent(String id) {
			Iterator<Student> iterator = students.iterator();
			for (Student student : students) {
				if(student.getId().equals(id)) { //so sanh
					students.remove(student);
					return true;
				}
			}
			return false;
		}

		// get all students who were born in a given birth year. //lay tat ca sv cung 1 năm sinh
		public ArrayList<Student> getStudentByBirthYear(int birthYear) {
			ArrayList<Student> list = new ArrayList<>();
			for (Student student : students) {
				if (student.getBirthYear() == birthYear) { //kiem tra
					list.add(student);
				}
			}
			return list;
		}
        //randomly select n students from the student list // chọn ngẫu nhiên 
		public ArrayList<Student> getRandomNStudents(int n){
			ArrayList<Student> randomStudents = new ArrayList<>();
//			Collections.shuffle(random); //trộn ds ngẫu nhiên 
//			if (n >= random.size()) {
//				return random;
//			}else {
//				return new ArrayList<>(random.subList(0, n));
//			}
			ArrayList<Integer> indices = new ArrayList<>();
	        Random random = new Random();

	        // Tạo danh sách các chỉ số ngẫu nhiên từ 0 đến (số lượng sinh viên - 1)
	        while (indices.size() < n) {
	            int index = random.nextInt(students.size());
	            if (!indices.contains(index)) {
	                indices.add(index);
	            }
	        }

	        // Lấy các sinh viên tương ứng từ danh sách gốc
	        for (int index : indices) {
	            randomStudents.add(students.get(index));
	        }

	        return randomStudents;
		}

		// similar as toString method, this method prints the name, year, and all
		// students of the class. Note that, using iterator
		public void display() {
			System.out.println("Name: "+ name + "Year: " + year );
			//System.out.println("Year: " + year);
			System.out.println("Student: ");
			Iterator<Student> i = students.iterator();
			while (i.hasNext()) {
				Student student = i.next();
				System.out.println(student.getFirstName() + " " + student.getLastName());
			}
		}
	
public static void main(String[] args) {
	// Tạo một đối tượng Clazz mới
	Clazz clazz = new Clazz();
	clazz.setName("Lớp DH22DTB ");
	clazz.setYear("2022");
	// sv
	Student s1 = new Student("1", "Nguyễn", "Mai", 2004, 3.0);
	Student s2 = new Student("2", "Nguyễn", "Tuyền", 2003, 3.1);
	Student s3 = new Student("3", "Nguyễn", "Huyền", 2003, 3.2);

    // thêm sv vào lớp
    clazz.addStudent(s1);
    clazz.addStudent(s2);
    clazz.addStudent(s3);

    // Hiện thị thông tin
    clazz.display();
 // tải từ file
    clazz.loadStudents("students.txt");

    // sắp xếp theo GPA
    clazz.sortStudents(Comparator.comparingDouble(Student::getGPA));

    // Display the sorted students
    System.out.println("Sorted Students:");
    clazz.display();

    // test topstudent
    ArrayList<Student> top = clazz.getTopNStudents(1);
    System.out.print("Sinh viên có GPA cao nhất: ");
    for (Student student : top) {
        System.out.println (student.getFirstName() + " " + student.getLastName());
    }

    // test remove
    boolean removed = clazz.removeStudent("2");
    if (removed) {
        System.out.println("Xóa thành công sinh viên có id '2'");
    } else {
        System.out.println("Không tìm thấy sinh viên có id '2'");
    }

    // Test getStudentByBirthYear
    ArrayList<Student> list = clazz.getStudentByBirthYear(2004);
    System.out.print("Sinh viên sinh năm 2004: ");
    for (Student student : list) {
        System.out.println(student.getFirstName() + " " + student.getLastName());
    }

    // random
    ArrayList<Student> randomStudents = clazz.getRandomNStudents(2);
    System.out.print("Random: ");
    for (Student student : randomStudents) {
        System.out.println(student.getFirstName() + " " + student.getLastName() + " ");
    }
}
}
