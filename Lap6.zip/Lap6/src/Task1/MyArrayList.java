package Task1;

import java.util.Arrays;
import java.util.Comparator;

	public class MyArrayList<E> {
		public static final int DEFAULT_CAPACITY = 10;
		private E[] elements;
		private int size;
		public MyArrayList() {
		this.elements = (E[]) new Object[DEFAULT_CAPACITY];
		}
		public MyArrayList(int capacity) {
		this.elements = (E[]) new Object[capacity];
		}
		// creates an array of double-size if the array of
		//elements is full
		public void growSize() {
			int newCapacity = elements.length * 2;
			E[] element = (E[])new Object[newCapacity];
			System.arraycopy(elements, 0, element, 0, size );
			elements = element;
		}
		// Returns the number of elements in this list.
		public int size() {
			return size;
		}
	
		// Returns whether the list is empty.(kt ds trống ko ?)
		public boolean isEmpty() {
		return size == 0;
		}
		// Returns (but does not remove) the element at index i.(trả về i)
		public E get(int i) throws IndexOutOfBoundsException{
			if (i < 0 || i >= size ) {
				throw new IndexOutOfBoundsException(); //nếu i< 0 (chỉ số âm) hoặc >= size.
			}
		return elements[i];
		}
		// Replaces the element at index i with e, and
		//returns the replaced element. (thay thế i = e ,trả về e)
		public E set(int i, E e) throws IndexOutOfBoundsException{
			if(i < 0 || i >= size) {
				throw new IndexOutOfBoundsException();
			}
			E newElement = elements[i];
			elements[i] = e;
			return newElement;
		}
		// It is used to append the specified element at the
		//end of a list.(nối phần tử vào cuối danh sách)
		public boolean add(E e) {
			if(size == elements.length) {  //kt phan tu hien tai co bang dung luong mang 
				growSize(); //tang dung luong
			}
			elements[size] = e;
			size++;
		return true;
		}
		// Inserts element e to be at index i, shifting all
		//subsequent elements later.(chen e vao i ,dich chuyen all vao sau)
		public void add(int i, E e) throws IndexOutOfBoundsException {
			if(i < 0 || i >= size) {
				throw new IndexOutOfBoundsException();
			}
			if(size == elements.length) {
				growSize();
			}
			System.arraycopy(elements, i, elements, i + 1, size - i);
//			for (int j = size -1; j >= i; j--) {
//				elements[j + 1] = elements[j]; //dich sang ben phai
//			}
			elements[i] = e;
			size++;
		}
		// Removes and returns the element at index i(loai bo ptu ),
		//shifting subsequent elements earlier (dich ve trc).
		public E remove(int i) throws IndexOutOfBoundsException {
			if(i < 0 || i >= size) {
				throw new IndexOutOfBoundsException();
			}
			E removeException = elements[i];
			System.arraycopy(elements, i + 1, elements, i, size - i - 1); 
//			for ( int j = i; j < size - 2; j++) {
//				elements[j] = elements[j + 1]; //dich sang trai
//			}
			elements[size - 1] = null; //xoa ptu cuoi cung
			size--;
		return removeException;
		}
		// It is used to clear all elements in the list.// xoa all ptu
		public void clear(){
			for (int i = 0; i < size; i++) {
				elements[i] = null;
			}
			size = 0; //ds trong
		}
		// It is used to return the index in this list of the
		//last occurrence of the specified element, or -1 if the
		//list does not contain this element.//kt ptu xuat hien cuoi cung ,tra ve -1 neu ko chua
		public int lastIndexOf(Object o) {
			for ( int i = size -1; i >= 0; i--) {
//				if( o == null) {
//					if (elements[i] == null) {
//						return i;
//					}
//				}else {
					if (o.equals(elements[i])) {
						return i;
					}
				}
			//}
		return -1;
		}
		// It is used to return an array containing all of the
		//elements in this list in the correct order. (trả về mảng chứa all ptu)
		public E[] toArray() {
			E[] newArray = (E[]) new Object[size]; // tao mang = ds
			System.arraycopy(elements, 0, newArray, 0, size);
//			for ( int i = 0; i < size; i++) {
//				newArray[i] = elements[i];
//			}
			return newArray;
			}
			// It is used to return a shallow copy of an ArrayList. // bản sao
			public MyArrayList<E> clone() {
				MyArrayList<E> cloneList = new MyArrayList<>();  //tạo ds mới để lưu
				cloneList.size = this.size;
				cloneList.elements = Arrays.copyOf(this.elements, this.size); //sử dụng Arrays.copyOf()để tạo một mảng mới elements cho clonedList
				System.arraycopy(elements, 0, cloneList.elements, 0, size);
				return cloneList;
			}
			// It returns true if the list contains the specified
			//element //ptu có trong ds ko
			public boolean contains(E o) {
			return indexOf(o) != -1;
			}
			// It is used to return the index in this list of the
			//first occurrence of the specified element, or -1 if the
			//List does not contain this element. //trả về lần xuất hiện đầu tiên của ptu ,trả về -1 nếu ko chứa
			public int indexOf(E o) {
				for (int i = 0; i < size; i++) {
					if(elements[i].equals(o)) {
						return i;
					}
				}
			return -1;
			}
			// It is used to remove the first occurrence of the
			//specified element. //loại bỏ ptu đc chỉ định
			public boolean remove(E e) {
				int index = indexOf(e);
				if (index != -1) {
					remove(index); //loại bỏ phần tử tại chỉ mục tìm thấy
					return true;
				}
			return false;
			}
			// It is used to sort the elements of the list on the
			//basis of specified comparator.
			public void sort(Comparator<E> c) {
				Arrays.sort(elements,0,size,c);
			}

public static void main(String[] args) {
	        MyArrayList<Integer> list = new MyArrayList<>();

	        //thêm ptu vào ds
	        list.add(10);
	        list.add(20);
	        list.add(30);

	        // in kích thước của ds
	        System.out.println("Size: " + list.size()); // Output: Size: 3

	        // in các ptu trong ds
	        System.out.println("Phần tử: " + Arrays.toString(list.toArray())); // Output: [10, 20, 30]

	        // kt ptu
	        int element = list.get(1);
	        System.out.println("Phần tử ở vị trí 1: " + element); // Output:20

	        // Thay thế ptu
	        int replacedElement = list.set(2, 40);
	        System.out.println("Phần tử đc thay thế: " + replacedElement); // Output: 30
	        System.out.println("Phần tử sau khi thay thế: " + Arrays.toString(list.toArray())); // Output: [10, 20, 40]

	        // chèn ptu
	        list.add(1, 15);
	        System.out.println("Phần tử sau khi chèn: " + Arrays.toString(list.toArray())); // Output: [10, 15, 20, 40]

	        // Xóa phần tử 
	        int removedElement = list.remove(0);
	        System.out.println("Phần tử đã xóa: " + removedElement); // Output: 10
	        System.out.println("Phần tử sau khi xóa: " + Arrays.toString(list.toArray())); // Output: [15, 20, 40]

	        // Kiểm tra ds có chứa ptu 20 ?
	        boolean containsElement = list.contains(20);
	        System.out.println("Danh sách chứa phần tử 20: " + containsElement); // Output: true

	        // Xóa ds
	        list.clear();
	        System.out.println("Size sau khi xóa: " + list.size()); // Output: 0
	        System.out.println("Các phần tử sau khi xóa: " + Arrays.toString(list.toArray())); // Output: []

	        //Sắp xếp ds
	        list.add(30);
	        list.add(10);
	        list.add(20);
	        list.sort(Comparator.naturalOrder());
	        System.out.println("Phần tử sau khi sắp xếp: " + Arrays.toString(list.toArray())); // Output: [10, 20, 30]
}
		
}
