package Task1;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

public class Node<E> {
	private E date;
	private Node<E> next;
	
	public Node(E data) {
		this.date = data;
	}
public Node(E data, Node<E> next) {
	this.date = data;
	this.next = next;
}

public void setNext(Node<E> next) {
	this.next = next;
}
public E getDate() {
	return date;
}
public Node<E> getNext() {
	return next;
}
public static class SinglyLinkedList<E>{
	private Node<E> head = null;
	private Node<E> tail = null;
	private int size;
	
	public SinglyLinkedList() {
		super();
	}
	// Returns the number of elements in the list. //trả về số phần tử trong danh sách
	public int size() {
		return size;
	}
	// Returns true if the list is empty, and false otherwise //kt ds trống
	public boolean isEmpty() {
		return size == 0;
	}
	// Returns (but does not remove) the first element in 
	//the list.
	public E first() {
		if (isEmpty()) {
			return null;
		}
	return head.getDate();
	}
	// Returns (but does not remove) the last element in the list.//trả về ptu cuối cùng 
	public E last()  {
		if (isEmpty()) {
			return null;
		}
		return tail.getDate();
	}
	// Adds a new element to the front of the list.//thêm ptu vào đầu ds
	public void addFirst(E e) {
		Node<E> newNode = new Node<>(e);
		if (isEmpty()) {
			head = newNode;
			tail = newNode;
		}else {
			newNode.next = head;
			head = newNode;
		}
		size++;
	}
	// Adds a new element to the end of the list.//thêm ptu vào cuối ds
	public void addLast(E e) {
		Node<E> newNode = new Node<>(e);
		if (isEmpty()) {
			head = newNode;
			tail = newNode;
		}else {
			tail.setNext(newNode);
			tail = newNode;
		}
		size++;
	}
	// Removes and returns the first element of the list. //xóa và trả về ptu đâu tiên
	public E removeFirst() {
		if (isEmpty()) {
			throw new NoSuchElementException("Danh sách trống");
		}
		E removedElement = head.getDate();
		if(head == tail) {
			head = null;
			tail = null;
		}else {
			head = head.getNext();
			
		}
		size--;
	return removedElement;
	}
	// Removes and returns the last element of the list. //xóa và trả về ptu cuối cùng
	public E removeLast() {
		if (isEmpty()) {
			return null;
		}
		E removedElement = tail.getDate();
		if (head == tail) {
			head = null;
			tail = null;
		}else {
			Node<E> current = head;
			while (current.getNext() != tail) {
				current = current.getNext();
			}
			current.setNext(null);
			tail = current;
		}
		size--;
	return removedElement;
		}

    public static void main(String[] args) {
    	SinglyLinkedList<Integer> list = new SinglyLinkedList<>();

    	//thêm ptu
        list.addFirst(10);
        list.addLast(20);
        list.addLast(30);
        
        //kt ds trống
        System.out.println("Danh sách trống? " + list.isEmpty());
        
        //in ds
        System.out.println("Size: " + list.size()); // Expected: 3
        System.out.println("Phần tử đầu tiên: " + list.first()); // Expected: 10
        System.out.println("Phần tử cuối cùng: " + list.last()); // Expected: 30

        //thêm ptu
        list.addFirst(40);
        System.out.println("Size: " + list.size()); // Expected: 2
        System.out.println("Phần tử đầu tiên: " + list.first()); // Expected: 40
        System.out.println("Phần tử cuối cùng: " + list.last()); // Expected: 30

        // xóa và in ptu đầu tiên
        //int removedElement = list.removeFirst();
        System.out.println("Xóa phần tử đầu tiên: " + list.removeFirst()); // Expected: 20
        System.out.println("Size: " + list.size()); // Expected: 3
        System.out.println("Phần tử đầu tiên: " + list.first()); // Expected: 10
        //System.out.println("Last element: " + list.last()); // Expected: 30

        //xóa và in ptu cuối cùng
        System.out.println("Xóa phần tử cuối cùng: " + list.removeLast()); // Expected: 30
        System.out.println("Size: " + list.size()); // Expected: 2
        //System.out.println("First element: " + list.first()); // Expected: 10
        System.out.println("Phần tử cuối cùng: " + list.last()); // Expected: 20
      }
    }
}