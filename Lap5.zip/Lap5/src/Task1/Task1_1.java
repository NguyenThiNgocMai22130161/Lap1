package Task1;

public class Task1_1 {
	// add 2 matrices
	public static int[][] add(int[][] a, int[][] b) {
	int n1 = a.length;
	int m1 = a[0].length;
	int[][] matrix1 = new int[n1][m1];
	for (int i = 0; i < n1; i++) {
		for (int j = 0; j < m1; j++) {
			matrix1[i][j] = a[i][j] + b[i][j];
		}
	}
	
	
	return matrix1;
	}
public static void main(String[] args) {
	int[][] a = {{7,2},{5,3}};
	int[][] b = {{2,1},{3,1}};
	
	int[][] matrix1 = add(a,b);
	
	for(int i = 0; i < matrix1.length; i++) {
		for (int j = 0; j < matrix1[0].length; j++) {
			System.out.print(matrix1[i][j] + " ");
		}System.out.println();
	}
			
	
}
}
