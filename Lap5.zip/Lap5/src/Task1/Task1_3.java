package Task1;

public class Task1_3 {
	// multiply 2 matrices
	public static int[][] multiply(int[][] a, int[][] b) {
	int n1 = a.length;
	int m1 = a[0].length;
	int m2 = b[0].length;
	int[][] matrix = new int[n1][m2];
	
	for (int i = 0; i < n1; i++) {
		for (int j = 0; j < m2; j++) {
			for(int k = 0; k < m1; k++) { 
				matrix[i][j] = matrix[i][j] + a[i][k] * b[k][j];	
			}
		}
	}
	return matrix;
	}
	public static void main(String[] args) {
		int[][] a = {{1,2,3},{5,6,7}};
		int[][] b = {{1,2,3},{4,5,6},{7,8,9}};
		int[][] matrix = multiply(a, b);
		for(int i = 0; i < matrix.length; i++) {
			for(int j = 0; j < matrix[0].length; j++) {
					System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
}
}
