package Task1;

public class Task1_2 {
	// subtract 2 matrices
	public static int[][]subtract(int[][] a, int[][] b) {
		int n2 = a.length;
		int m2 = a[0].length;
	int[][] matrix2 = new int[n2][m2];
	
	for (int i = 0; i < n2; i++) {
		for (int j = 0; j < m2; j++) {
			matrix2[i][j] = a[i][j] - b[i][j];
		}
	}
	return matrix2;
	}
	public static void main(String[] args) {
		int[][] a = {{7,2},{5,3}};
		int[][] b = {{2,1},{3,1}};
		
		int[][] matrix2 = subtract(a, b);
		
		for(int i = 0; i < matrix2.length; i++) {
			for (int j = 0; j < matrix2[0].length; j++) {
				System.out.print(matrix2[i][j] + " ");
			}
			System.out.println();
		}
		
	}
	
}
