package Task2;
import java.util.Scanner;

public class Tictoctoe {
    private static final int BOARD_SIZE = 3;
    private static final char EMPTY = ' ';
    private char[][] board;
    private char currentPlayer;

    public Tictoctoe() {
        board = new char[BOARD_SIZE][BOARD_SIZE];
        currentPlayer = 'X';
        initializeBoard();
    }

    private void initializeBoard() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                board[row][col] = EMPTY;
            }
        }
    }

    private void printBoard() {
        System.out.println("-------------");
        for (int row = 0; row < BOARD_SIZE; row++) {
            System.out.print("| ");
            for (int col = 0; col < BOARD_SIZE; col++) {
                System.out.print(board[row][col] + " | ");
            }
            System.out.println("\n-------------");
        }
    }

    private boolean isBoardFull() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if (board[row][col] == EMPTY) {// kiểm tra xem có còn trống ô đó không
                    return false;
                }
            }
        }
        return true;
    }
    /*
	 * This method checks all rows and returns true if any of them are marked with
	 * all of a single player's markers. Otherwise, returns false.
	 */
    private boolean checkRows() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            if (board[row][0] != EMPTY && board[row][0] == board[row][1] && board[row][0] == board[row][2]) {
                return true;
            }
        }
        return false;
    }

    private boolean checkColumns() {
        for (int col = 0; col < BOARD_SIZE; col++) {
            if (board[0][col] != EMPTY && board[0][col] == board[1][col] && board[0][col] == board[2][col]) {
                return true;
            }
        }
        return false;
    }
    /*
	 * This method checks both diagonals and returns true if any of them are marked
	 * with all of a single player's markers. Otherwise, returns false.
	 */
    private boolean checkDiagonals() {
    	// Check top-left to bottom-right
        if (board[0][0] != EMPTY && board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
            return true;
        }
     // Check bottom-left to top-right
        if (board[0][2] != EMPTY && board[0][2] == board[1][1] && board[0][2] == board[2][0]) {
            return true;
        }
        return false;
    }

    private boolean checkWin() {
        return checkRows() || checkColumns() || checkDiagonals();
    }

    private void makeMove(int row, int col) {
        if (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE && board[row][col] == EMPTY) {
            board[row][col] = currentPlayer;
        } else {
            System.out.println("Invalid move. Try again.");
            switchPlayer();
        }
    }

    private void switchPlayer() {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    public void playGame() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Tic Tac Toe Game");
        System.out.println("Enter row and column numbers (0-2) to make a move.");

        while (true) {
            System.out.println("\nCurrent Board:");
            printBoard();
            System.out.println("Player " + currentPlayer + "'s turn.");

            System.out.print("Enter row: ");
            int row = scanner.nextInt();

            System.out.print("Enter column: ");
            int col = scanner.nextInt();

            makeMove(row, col);

            if (checkWin()) {
                System.out.println("\nPlayer " + currentPlayer + " wins!");
                break;
            } else if (isBoardFull()) {
                System.out.println("\nThe game is a draw!");
                break;
            }

            switchPlayer();
        }
        System.out.println("\nGame Over.");
        printBoard();
        scanner.close();
    }

    public static void main(String[] args) {
        Tictoctoe game = new Tictoctoe();
        game.playGame();
    }
}